"""
The module that offers several Net2 related network utilities
"""
